﻿// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <list>


// Include GLEW
//#define GLEW_STATIC
#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>
GLFWwindow* window;

// Include GLM
#include <include/glm.hpp>
#include <include/gtc/matrix_transform.hpp>
using namespace glm;

#include "shader.hpp"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

bool textureEnabled = true; //boolean that controls if the texture should be enabled, correspondig to the press of button T.

glm::mat4 ViewMatrix;
glm::mat4 ProjectionMatrix;
glm::mat4 ModelMatrix;
float trasformSphereX = 50.0f;
float trasformSphereY = 50.0f;
float trasformSphereZ = 50.0f;

glm::mat4 getViewMatrix() {
	return ViewMatrix;
}
glm::mat4 getProjectionMatrix() {
	return ProjectionMatrix;
}

glm::mat4 getModelMatrix() {
	return ModelMatrix;
}

// Initial position 
glm::vec3 position = glm::vec3(50, 50, 230);
// Initial horizontal angle : toward -Z
float horizontalAngle = 3.14f;
// Initial vertical angle : none
float verticalAngle = 0.0f;
// Initial Field of View
float initialFoV = 45.0f;

float speed = 40.0f; // 3 units / second
float mouseSpeed = 0.005f;



//This function is called when a button is pressed.
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	//Commands that change the position of the main sphere by changing the transformation quantity to the model matrix.
	if (key == GLFW_KEY_LEFT && action == GLFW_PRESS)
	{
		//Only changes the transformation quantity if the sphere wouldn't go out of cube's bounds.
		if (trasformSphereX >= 16) {
			trasformSphereX -= 1.0f;
		}
	}
	if (key == GLFW_KEY_RIGHT && action == GLFW_PRESS)
	{
		if (trasformSphereX < 84) {
			trasformSphereX += 1.0f;
		}
	}
	if (key == GLFW_KEY_UP && action == GLFW_PRESS)
	{
		if (trasformSphereY < 84) {
			trasformSphereY += 1.0f;
		}
	}
	if (key == GLFW_KEY_DOWN && action == GLFW_PRESS)
	{
		if (trasformSphereY > 16) {
			trasformSphereY -= 1.0f;
		}
	}
	if (key == GLFW_KEY_KP_ADD && action == GLFW_PRESS)
	{
		if (trasformSphereZ < 84) {
			trasformSphereZ += 1.0f;
		}
	}
	if (key == GLFW_KEY_KP_SUBTRACT && action == GLFW_PRESS)
	{
		if (trasformSphereZ > 16) {
			trasformSphereZ -= 1.0f;
		}
	}
	//Command to enable/disable the texture
	if (key == GLFW_KEY_T && action == GLFW_PRESS)
	{
		textureEnabled = !textureEnabled;
	}
}


void computeMatricesFromInputs() {

	// glfwGetTime is called only once, the first time this function is called
	static double lastTime = glfwGetTime();

	// Compute time difference between current and last frame
	double currentTime = glfwGetTime();
	float deltaTime = float(currentTime - lastTime);

	// Get mouse position
	double xpos, ypos;
	glfwGetCursorPos(window, &xpos, &ypos);

	// Reset mouse position for next frame
	glfwSetCursorPos(window, 600 / 2, 600 / 2);

	// Compute new orientation
	horizontalAngle += mouseSpeed* float(600 / 2 - xpos);
	verticalAngle += mouseSpeed* float(600 / 2 - ypos);
	
	// Direction : Spherical coordinates to Cartesian coordinates conversion
	glm::vec3 direction(
		cos(verticalAngle) * sin(horizontalAngle),
		sin(verticalAngle),
		cos(verticalAngle) * cos(horizontalAngle)
	);

	// Right vector
	glm::vec3 right = glm::vec3(
		sin(horizontalAngle - 3.14f / 2.0f),
		0,
		cos(horizontalAngle - 3.14f / 2.0f)
	);

	// Up vector
	glm::vec3 up = glm::cross(right, direction);

	// Move forward
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		position += direction * deltaTime * speed;
	}
	// Move backward
	if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
		position -= direction * deltaTime * speed;
	}
	// Strafe right
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		position += right * deltaTime * speed;
		horizontalAngle += mouseSpeed * 0.014f ;

	}
	// Strafe left
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		position -= right * deltaTime * speed;
		horizontalAngle -= mouseSpeed * 0.014f;
	}
	// Move up
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		position += up * deltaTime * speed;
		verticalAngle -= mouseSpeed * 0.014f;
	}
	// Move down
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		position -= up * deltaTime * speed;
		verticalAngle += mouseSpeed * 0.014f;
	}

	float FoV = initialFoV;

	// Projection matrix : 45° Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
	ProjectionMatrix = glm::perspective(glm::radians(FoV), 4.0f / 3.0f, 0.1f, 1000.0f);
	// Camera matrix
	ViewMatrix = glm::lookAt(
		position,           // Camera is here
		position+direction, // and looks here : at the same position, plus "direction"
		up                  // Head is up (set to 0,-1,0 to look upside-down)
	);

	// For the next frame, the "last time" will be "now"
	lastTime = currentTime;
}



int main(void)
{
	//Set a seed for randomizer
	srand(time(NULL));
	
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	window = glfwCreateWindow(600, 600, u8"Συγκρουόμενα", NULL, NULL);

	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
	// Hide the mouse and enable unlimited mouvement
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	// Set the mouse at the center of the screen
	glfwPollEvents();
	glfwSetCursorPos(window, 600 / 2, 600 / 2);
	// Dark blue background
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);
	// Accept fragment if it closer to the camera than the former one
	glDepthFunc(GL_LESS);
	// Cull triangles which normal is not towards the camera
	glEnable(GL_CULL_FACE);
	

	// Create and compile our GLSL program from the shaders
	GLuint programID = LoadShaders("TransformVertexShader.vertexshader", "ColorFragmentShader.fragmentshader");

	// Get a handle for our "MVP" uniform
	GLuint MatrixID = glGetUniformLocation(programID, "MVP");
	GLuint MatrixMVID = glGetUniformLocation(programID, "MV");

	// load BMP image
	unsigned int texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_R, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	int width, height, nrChannels;
	unsigned char* data = stbi_load("texture.jpg", &width, &height, &nrChannels, 0);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_2D);
	stbi_image_free(data);

	glfwSetKeyCallback(window, key_callback);
	
	//END OF INITIALIZATION

	//bind our VAO
	unsigned int VAO;
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);

	// The main Cube's initialization; 
	// The vertices of the cube. Three consecutive vertices give a triangle. A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
	static const GLfloat g_vertex_buffer_data[] = {
		0.0f,0.0f,0.0f,        
		0.0f,0.0f, 100.0f,	   
		0.0f, 100.0f, 100.0f,  
		100.0f, 100.0f,0.0f,   
		0.0f,0.0f,0.0f,		   
		0.0f, 100.0f,0.0f,	   
		100.0f,0.0f, 100.0f,   
		0.0f,0.0f,0.0f,		   
		100.0f,0.0f,0.0f,	   
		100.0f, 100.0f,0.0f,   
		100.0f,0.0f,0.0f,	   
		0.0f,0.0f,0.0f,		   
		0.0f,0.0f,0.0f,		   
		0.0f, 100.0f, 100.0f,  
		0.0f, 100.0f,0.0f,	   
		100.0f, 0.0f, 100.0f,  
		0.0f,0.0f, 100.0f,	   
		0.0f,0.0f,0.0f,		   
		0.0f, 100.0f, 100.0f,  
		0.0f,0.0f, 100.0f,	   
		100.0f,0.0f, 100.0f,   
		100.0f, 100.0f, 100.0f,
		100.0f,0.0f,0.0f,	   
		100.0f, 100.0f,0.0f,   
		100.0f,0.0f,0.0f,	   
		100.0f, 100.0f, 100.0f,
		100.0f,0.0f, 100.0f,   
		100.0f, 100.0f, 100.0f,
		100.0f, 100.0f,0.0f,   
		0.0f, 100.0f,0.0f,	   
		100.0f, 100.0f, 100.0f,
		0.0f, 100.0f,0.0f,	   
		0.0f, 100.0f, 100.0f,  
		100.0f, 100.0f, 100.0f,
		0.0f, 100.0f, 100.0f,  
		100.0f,0.0f, 100.0f	   
	};

	
	//Calculate a random color for the cube.
	GLfloat random_color = (GLfloat)((float)(rand() % 2));
	GLfloat random_color2 = (GLfloat)((float)(rand() % 2));
	GLfloat random_color3 = (GLfloat)((float)(rand() % 2));
	
	// One color for each vertex. They were generated randomly.
	static const GLfloat g_color_buffer_data[] = { 
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3
	};

	//indices for the rendering of the cube outline
	GLuint indicesCube[24] = {
		0, 5,
		0, 8,
		0, 16,
		2, 1,
		16, 6,
		3, 5,
		3, 21,
		5, 2,
		8, 3,
		8, 6,
		21, 2,
		21, 6
	};

	
	//Bind the cube VBOs
	GLuint vertexbuffer;
	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_vertex_buffer_data), g_vertex_buffer_data, GL_STATIC_DRAW);

	GLuint colorbuffer;
	glGenBuffers(1, &colorbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_color_buffer_data), g_color_buffer_data, GL_STATIC_DRAW);
	
	GLuint iboCubeId;
	glGenBuffers(1, &iboCubeId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboCubeId);   
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,          
		sizeof(indicesCube),            
		indicesCube,               
		GL_STATIC_DRAW);
	
	

	//Create the Sphere
	float radius= 15.0f;
	const int sectorCount =15;                        // longitude, # of slices
	const int stackCount =10;
	float PI = acos(-1);
	GLfloat vertices[(stackCount+1)*(sectorCount+1)*3];
	GLfloat normals[(stackCount+1) * (sectorCount+1) * 3];
	GLfloat texCoords[(stackCount+1)*(sectorCount+1)*2];
	GLfloat colors[(stackCount+1) * (sectorCount+1) * 3];
	GLfloat colorsWhite[(stackCount + 1) * (sectorCount + 1) * 3];
	GLuint indices[stackCount*sectorCount*6-sectorCount*6];
	


	float x, y, z, xy;                              // vertex position
	float nx, ny, nz, lengthInv = 1.0f / radius;    // vertex normal
	float s, t;                                     // vertex texCoord

	float sectorStep = 2 * PI / sectorCount;
	float stackStep = PI / stackCount;
	float sectorAngle, stackAngle;
	int counter = 0;
	int texcounter = 0;
	for (int i = 0; i <= stackCount; ++i)
	{
		stackAngle = PI / 2 - i * stackStep;        // starting from pi/2 to -pi/2
		xy = radius * cosf(stackAngle);             // r * cos(u)
		z = radius * sinf(stackAngle);              // r * sin(u)

		// add (sectorCount+1) vertices per stack
		// the first and last vertices have same position and normal, but different tex coords
		for (int j = 0; j <= sectorCount; ++j)
		{
			sectorAngle = j * sectorStep;           // starting from 0 to 2pi

			// vertex position (x, y, z)
			x = xy * cosf(sectorAngle);             // r * cos(u) * cos(v)
			y = xy * sinf(sectorAngle);             // r * cos(u) * sin(v)
			vertices[counter] = x;
			vertices[counter+1] = y;
			vertices[counter+2] = z;

			// normalized vertex normal (nx, ny, nz)
			nx = x * lengthInv;
			ny = y * lengthInv;
			nz = z * lengthInv;
			normals[counter] = nx;
			normals[counter + 1] = ny;
			normals[counter + 2] = nz;

			// vertex tex coord (s, t) range between [0, 1]
			s = (float)j / sectorCount;
			t = (float)i / stackCount;
			texCoords[texcounter] = s;
			texCoords[texcounter+1] = t;
			texcounter += 2;

			//colors (harcoded red)
			colors[counter] = 1.0f;
			colors[counter + 1] = 0.0f;
			colors[counter + 2] = 0.0f;
			colorsWhite[counter] = 1.0f;
			colorsWhite[counter + 1] = 1.0f;
			colorsWhite[counter + 2] = 1.0f;
			counter += 3;
		}
		
	}
	counter = 0;
	int k1, k2;
	for (int i = 0; i < stackCount; ++i)
	{
		k1 = i * (sectorCount + 1);     // beginning of current stack
		k2 = k1 + sectorCount + 1;      // beginning of next stack

		for (int j = 0; j < sectorCount; ++j, ++k1, ++k2)
		{
			// 2 triangles per sector excluding first and last stacks
			// k1 => k2 => k1+1
			if (i != 0)
			{
				indices[counter]   = k1;
				indices[counter+1] = k2;
				indices[counter+2] = k1+1;
				counter += 3;
			}

			// k1+1 => k2 => k2+1
			if (i != (stackCount - 1))
			{
				indices[counter]   = k1+1;
				indices[counter+1] = k2;
				indices[counter+2] = k2 + 1;
				counter += 3;
			}
		}
	}
	
	//Bind the VBOs for the sphere
	GLuint vboSphereId;
	glGenBuffers(1, &vboSphereId);
	glBindBuffer(GL_ARRAY_BUFFER, vboSphereId);           // for vertex data
	glBufferData(GL_ARRAY_BUFFER,                   // target
		sizeof(vertices), // data size, # of bytes
		vertices,   // ptr to vertex data
		GL_STATIC_DRAW);   // usage

	GLuint normalsSphereId;
	glGenBuffers(1, &normalsSphereId);
	glBindBuffer(GL_ARRAY_BUFFER, normalsSphereId);           // for vertex data
	glBufferData(GL_ARRAY_BUFFER,                   // target
		sizeof(normals), // data size, # of bytes
		normals,   // ptr to vertex data
		GL_DYNAMIC_DRAW);   // usage

	GLuint colorsSphereID;
	glGenBuffers(1, &colorsSphereID);
	glBindBuffer(GL_ARRAY_BUFFER, colorsSphereID);   // for index data
	glBufferData(GL_ARRAY_BUFFER,           // target
		sizeof(colors),             // data size, # of bytes
		colors,               // ptr to index data
		GL_STATIC_DRAW);
	
	GLuint colorsWhiteSphereID;
	glGenBuffers(1, &colorsWhiteSphereID);
	glBindBuffer(GL_ARRAY_BUFFER, colorsWhiteSphereID);   // for index data
	glBufferData(GL_ARRAY_BUFFER,           // target
		sizeof(colorsWhite),             // data size, # of bytes
		colorsWhite,               // ptr to index data
		GL_STATIC_DRAW);

	GLuint texSphereId;
	glGenBuffers(1, &texSphereId);
	glBindBuffer(GL_ARRAY_BUFFER, texSphereId);   // for index data
	glBufferData(GL_ARRAY_BUFFER,           // target
		sizeof(texCoords),             // data size, # of bytes
		texCoords,               // ptr to index data
		GL_STATIC_DRAW);

// copy index data to VBO
	GLuint iboSphereId;
	glGenBuffers(1, &iboSphereId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboSphereId);   // for index data
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,           // target
		sizeof(indices),             // data size, # of bytes
		indices,               // ptr to index data
		GL_STATIC_DRAW);
	                 


	do {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		//DRAW THE CUBE

		// Compute the MVP matrix from keyboard and mouse input
		computeMatricesFromInputs();
		ProjectionMatrix = getProjectionMatrix();
		ViewMatrix = getViewMatrix();
		ModelMatrix = glm::mat4(1.0);
		glm::mat4 MVP = ProjectionMatrix * ViewMatrix * ModelMatrix;
		glm::mat4 MV = ViewMatrix * ModelMatrix;


		// Send our transformation to the currently bound shader, 
		// in the "MVP" uniform
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
		glUniformMatrix4fv(MatrixMVID, 1, GL_FALSE, &MV[0][0]);

		//Draw the outline of the main cube
		
		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
		glVertexAttribPointer(
			0,                  // attribute. No particular reason for 0, but must match the layout in the shader.
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// 2nd attribute buffer : colors
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
		glVertexAttribPointer(
			1,                                // attribute. No particular reason for 1, but must match the layout in the shader.
			3,                                // size
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		//Bind the indexes of the cube vertex buffer and then draw.
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboCubeId);
		glDrawElements(
			GL_LINES,
			sizeof(indicesCube),
			GL_UNSIGNED_INT,
			(void*)0
		);

		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);



		//DRAW THE SPHERE
		
		//enable blending
		glDisable(GL_BLEND);
		//Trasnform the Model Matrix so that the sphere renders in world coords (trasformSphereX, trasformSphereY, trasformSphereZ). initially (50,50,50)
		ModelMatrix = glm::mat4(1.0);
		ModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(trasformSphereX, trasformSphereY, trasformSphereZ));
		 MVP = ProjectionMatrix * ViewMatrix * ModelMatrix;//*MVP;
		 MV = ViewMatrix * ModelMatrix; //*MV;

		// Send our transformation to the currently bound shader, 
		// in the "MVP" uniform
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
		glUniformMatrix4fv(MatrixMVID, 1, GL_FALSE, &MV[0][0]);
		glUseProgram(programID);

		//Enable the Vbos
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vboSphereId);
		glVertexAttribPointer(
			0,                  // attribute. No particular reason for 0, but must match the layout in the shader.
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		//only enable the texture VBO if textures are currently enabled. Enables a color VBO that contains the color red if textures are disabled and one with white color otherwise.
		if (textureEnabled == false) {
			glEnableVertexAttribArray(1);
			glBindBuffer(GL_ARRAY_BUFFER, colorsSphereID);
			glVertexAttribPointer(
				1,                  // attribute. No particular reason for 1, but must match the layout in the shader.
				3,                  // size
				GL_FLOAT,           // type
				GL_FALSE,           // normalized?
				0,                  // stride
				(void*)0            // array buffer offset
			);
		}
		else {
			glEnableVertexAttribArray(1);
			glBindBuffer(GL_ARRAY_BUFFER, colorsWhiteSphereID);
			glVertexAttribPointer(
				1,                  // attribute. No particular reason for 1, but must match the layout in the shader.
				3,                  // size
				GL_FLOAT,           // type
				GL_FALSE,           // normalized?
				0,                  // stride
				(void*)0            // array buffer offset
			);

			glEnableVertexAttribArray(2);
			glBindBuffer(GL_ARRAY_BUFFER, texSphereId);
			glVertexAttribPointer(
				2,                  // attribute. No particular reason for 0, but must match the layout in the shader.
				2,                  // size
				GL_FLOAT,           // type
				GL_FALSE,           // normalized?
				0,                  // stride
				(void*)0            // array buffer offset
			);

			glBindTexture(GL_TEXTURE_2D, texture);
		}
		//Bind the sphere's indeces IBO and draws.
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iboSphereId);
		glDrawElements(
			GL_TRIANGLES,
			sizeof(indices),
			GL_UNSIGNED_INT,
			(void*)0
		);
		
		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);
		if (textureEnabled == true) {
			glDisableVertexAttribArray(2);
		}


		//Enables blending so that the main cube is rendered transparent.
		glEnable(GL_BLEND);
		glBlendColor(0.0f, 0.0f, 0.0f, 0.3f);
		glBlendFunc(GL_CONSTANT_ALPHA, GL_ONE_MINUS_CONSTANT_ALPHA);
		
		// Use our shader
		glUseProgram(programID);

		//DRAW THE CUBE

		// Compute the MVP matrix from keyboard and mouse input
		computeMatricesFromInputs();
		ProjectionMatrix = getProjectionMatrix();
		ViewMatrix = getViewMatrix();
		ModelMatrix = glm::mat4(1.0);
		MVP = ProjectionMatrix * ViewMatrix * ModelMatrix;
		MV = ViewMatrix * ModelMatrix;

		// Send our transformation to the currently bound shader, 
		// in the "MVP" uniform
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);
		glUniformMatrix4fv(MatrixMVID, 1, GL_FALSE, &MV[0][0]);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
		glVertexAttribPointer(
			0,                  // attribute. No particular reason for 0, but must match the layout in the shader.
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);

		// 2nd attribute buffer : colors
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
		glVertexAttribPointer(
			1,                                // attribute. No particular reason for 1, but must match the layout in the shader.
			3,                                // size
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		// Draw the main cube !
		glDrawArrays(GL_TRIANGLES, 0, 12 * 3); // 12*3 indices starting at 0 -> 12 triangles

		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);

		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();

	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
		glfwWindowShouldClose(window) == 0);

	// Cleanup VBO and shader
	glDeleteBuffers(1, &vertexbuffer);
	glDeleteBuffers(1, &iboCubeId);
	glDeleteBuffers(1, &vboSphereId);
	glDeleteBuffers(1, &normalsSphereId);
	glDeleteBuffers(1, &colorsSphereID);
	glDeleteBuffers(1, &colorsWhiteSphereID);
	glDeleteBuffers(1, &texSphereId);
	glDeleteBuffers(1, &iboSphereId);
	glDeleteProgram(programID);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}

