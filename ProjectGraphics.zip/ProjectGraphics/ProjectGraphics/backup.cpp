﻿// Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cmath>
#include <vector>


// Include GLEW
//#define GLEW_STATIC
#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>
GLFWwindow* window;

// Include GLM
#include <include/glm.hpp>
#include <include/gtc/matrix_transform.hpp>
using namespace glm;

#include "shader.hpp"
#include "Sphere.h"
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

glm::mat4 ViewMatrix;
glm::mat4 ProjectionMatrix;

glm::mat4 getViewMatrix() {
	return ViewMatrix;
}
glm::mat4 getProjectionMatrix() {
	return ProjectionMatrix;
}


// Initial position 
glm::vec3 position = glm::vec3(50, 50, 230);
// Initial horizontal angle : toward -Z
float horizontalAngle = 3.14f;
// Initial vertical angle : none
float verticalAngle = 0.0f;
// Initial Field of View
float initialFoV = 45.0f;

float speed = 40.0f; // 3 units / second
float mouseSpeed = 0.005f;




void computeMatricesFromInputs() {

	// glfwGetTime is called only once, the first time this function is called
	static double lastTime = glfwGetTime();

	// Compute time difference between current and last frame
	double currentTime = glfwGetTime();
	float deltaTime = float(currentTime - lastTime);

	// Get mouse position
	//double xpos, ypos;
	//glfwGetCursorPos(window, &xpos, &ypos);

	// Reset mouse position for next frame
	//glfwSetCursorPos(window, 600 / 2, 600 / 2);

	// Compute new orientation
	//std::cout << xpos;
	horizontalAngle += 0; // mouseSpeed* float(600 / 2 - xpos);
	verticalAngle += 0; // mouseSpeed* float(600 / 2 - ypos);
	
	// Direction : Spherical coordinates to Cartesian coordinates conversion
	glm::vec3 direction(
		cos(verticalAngle) * sin(horizontalAngle),
		sin(verticalAngle),
		cos(verticalAngle) * cos(horizontalAngle)
	);

	// Right vector
	glm::vec3 right = glm::vec3(
		sin(horizontalAngle - 3.14f / 2.0f),
		0,
		cos(horizontalAngle - 3.14f / 2.0f)
	);

	// Up vector
	glm::vec3 up = glm::cross(right, direction);

	// Move forward
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {
		position += direction * deltaTime * speed;
	}
	// Move backward
	if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS) {
		position -= direction * deltaTime * speed;
	}
	// Strafe right
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
		position += right * deltaTime * speed;
		horizontalAngle += mouseSpeed * 0.014f;

	}
	// Strafe left
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
		position -= right * deltaTime * speed;
		horizontalAngle -= mouseSpeed * 0.014f;
	}
	// Move up
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
		position += up * deltaTime * speed;
		verticalAngle -= mouseSpeed * 0.014f;
	}
	// Move down
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
		position -= up * deltaTime * speed;
		verticalAngle += mouseSpeed * 0.014f;
	}

	float FoV = initialFoV;// - 5 * glfwGetMouseWheel(); // Now GLFW 3 requires setting up a callback for this. It's a bit too complicated for this beginner's tutorial, so it's disabled instead.

	// Projection matrix : 45° Field of View, 4:3 ratio, display range : 0.1 unit <-> 100 units
	ProjectionMatrix = glm::perspective(glm::radians(FoV), 4.0f / 3.0f, 0.1f, 1000.0f);
	// Camera matrix
	ViewMatrix = glm::lookAt(
		position,           // Camera is here
		vec3(50,50,50), // and looks here : at the same position, plus "direction"
		up                  // Head is up (set to 0,-1,0 to look upside-down)
	);

	// For the next frame, the "last time" will be "now"
	lastTime = currentTime;
}





int main(void)
{
	//Set a seed for randomizer
	srand(time(NULL));
	
	// Initialise GLFW
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		getchar();
		return -1;
	}

	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	//glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Open a window and create its OpenGL context
	window = glfwCreateWindow(600, 600, u8"Συγκρουόμενα", NULL, NULL);

	if (window == NULL) {
		fprintf(stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n");
		getchar();
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);

	// Initialize GLEW
	glewExperimental = true; // Needed for core profile
	if (glewInit() != GLEW_OK) {
		fprintf(stderr, "Failed to initialize GLEW\n");
		getchar();
		glfwTerminate();
		return -1;
	}

	// Ensure we can capture the escape key being pressed below
	glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);
	// Hide the mouse and enable unlimited mouvement
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	// Set the mouse at the center of the screen
	glfwPollEvents();
	glfwSetCursorPos(window, 600 / 2, 600 / 2);
	// Dark blue background
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);
	// Accept fragment if it closer to the camera than the former one
	glDepthFunc(GL_LESS);
	// Cull triangles which normal is not towards the camera
	glEnable(GL_CULL_FACE);

	GLuint VertexArrayID;
	glGenVertexArrays(1, &VertexArrayID);
	glBindVertexArray(VertexArrayID);

	// Create and compile our GLSL program from the shaders
	GLuint programID = LoadShaders("TransformVertexShader.vertexshader", "ColorFragmentShader.fragmentshader");

	// Get a handle for our "MVP" uniform
	GLuint MatrixID = glGetUniformLocation(programID, "MVP");

	// load BMP image
	unsigned int texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	int width, height, nrChannels;
	unsigned char* data = stbi_load("texture.jpg", &width, &height, &nrChannels, 0);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
	glGenerateMipmap(GL_TEXTURE_2D);
	stbi_image_free(data);
	
	//END OF INITIALIZATION -----------------------------------------------------------------------------------------------------------------------------------------------

	// Our vertices. Tree consecutive floats give a 3D vertex; Three consecutive vertices give a triangle.
	// A cube has 6 faces with 2 triangles each, so this makes 6*2=12 triangles, and 12*3 vertices
	static const GLfloat g_vertex_buffer_data[] = {
		0.0f,0.0f,0.0f,      
		0.0f,0.0f, 100.0f,
		0.0f, 100.0f, 100.0f,
		100.0f, 100.0f,0.0f,
		0.0f,0.0f,0.0f,
		0.0f, 100.0f,0.0f,
		100.0f,0.0f, 100.0f,
		0.0f,0.0f,0.0f,
		100.0f,0.0f,0.0f,
		100.0f, 100.0f,0.0f,
		100.0f,0.0f,0.0f,
		0.0f,0.0f,0.0f,
		0.0f,0.0f,0.0f,
		0.0f, 100.0f, 100.0f,
		0.0f, 100.0f,0.0f,
		100.0f, 0.0f, 100.0f,
		0.0f,0.0f, 100.0f,
		0.0f,0.0f,0.0f,
		0.0f, 100.0f, 100.0f,
		0.0f,0.0f, 100.0f,
		100.0f,0.0f, 100.0f,
		100.0f, 100.0f, 100.0f,
		100.0f,0.0f,0.0f,
		100.0f, 100.0f,0.0f,
		100.0f,0.0f,0.0f,
		100.0f, 100.0f, 100.0f,
		100.0f,0.0f, 100.0f,
		100.0f, 100.0f, 100.0f,
		100.0f, 100.0f,0.0f,
		0.0f, 100.0f,0.0f,
		100.0f, 100.0f, 100.0f,
		0.0f, 100.0f,0.0f,
		0.0f, 100.0f, 100.0f,
		100.0f, 100.0f, 100.0f,
		0.0f, 100.0f, 100.0f,
		100.0f,0.0f, 100.0f
	};

	GLfloat random_color = (GLfloat)((float)(rand() % 2));
	GLfloat random_color2 = (GLfloat)((float)(rand() % 2));
	GLfloat random_color3 = (GLfloat)((float)(rand() % 2));
	
	// One color for each vertex. They were generated randomly.
	static const GLfloat g_color_buffer_data[] = { 
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
		random_color, random_color2, random_color3,
	};

	GLuint vertexbuffer;
	glGenBuffers(1, &vertexbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_vertex_buffer_data), g_vertex_buffer_data, GL_STATIC_DRAW);

	GLuint colorbuffer;
	glGenBuffers(1, &colorbuffer);
	glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(g_color_buffer_data), g_color_buffer_data, GL_STATIC_DRAW);

	glEnable(GL_BLEND);
	glBlendColor(0.0f, 0.0f, 0.0f, 0.3f);
	glBlendFunc(GL_CONSTANT_ALPHA, GL_ONE_MINUS_CONSTANT_ALPHA);
	
	//create main sphere
	Sphere mainsphere(1.5f, 36, 18);
	                 


	do {
		// Clear the screen
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Use our shader
		glUseProgram(programID);

		// Compute the MVP matrix from keyboard and mouse input
		computeMatricesFromInputs();
		glm::mat4 ProjectionMatrix = getProjectionMatrix();
		glm::mat4 ViewMatrix = getViewMatrix();
		glm::mat4 ModelMatrix = glm::mat4(1.0);
		glm::mat4 MVP = ProjectionMatrix * ViewMatrix * ModelMatrix;


		// Send our transformation to the currently bound shader, 
		// in the "MVP" uniform
		glUniformMatrix4fv(MatrixID, 1, GL_FALSE, &MVP[0][0]);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, vertexbuffer);
		glVertexAttribPointer(
			0,                  // attribute. No particular reason for 0, but must match the layout in the shader.
			3,                  // size
			GL_FLOAT,           // type
			GL_FALSE,           // normalized?
			0,                  // stride
			(void*)0            // array buffer offset
		);
		
		

		// 2nd attribute buffer : colors

		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, colorbuffer);
		glVertexAttribPointer(
			1,                                // attribute. No particular reason for 1, but must match the layout in the shader.
			3,                                // size
			GL_FLOAT,                         // type
			GL_FALSE,                         // normalized?
			0,                                // stride
			(void*)0                          // array buffer offset
		);

		//Draw the lines of the main cube
		glDrawArrays(GL_LINES, 0, 12 * 3);
		// Draw the main cube !
		glDrawArrays(GL_TRIANGLES, 0, 12 * 3); // 12*3 indices starting at 0 -> 12 triangles
		
		glDisableVertexAttribArray(0);
		glDisableVertexAttribArray(1);
		

		
		float lineColor[] = { 0.2f, 0.2f, 0.2f, 1 };
		mainsphere.drawWithLines(lineColor);

		// Swap buffers
		glfwSwapBuffers(window);
		glfwPollEvents();
		

	} // Check if the ESC key was pressed or the window was closed
	while (glfwGetKey(window, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
		glfwWindowShouldClose(window) == 0);

	// Cleanup VBO and shader
	glDeleteBuffers(1, &vertexbuffer);
	glDeleteBuffers(1, &colorbuffer);
	glDeleteProgram(programID);
	glDeleteVertexArrays(1, &VertexArrayID);

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;
}

